from setuptools import setup

setup(
    name = 'mkdirPypi',
    version = '1.0.0',
    author = 'Maycon Cypriano Batestin',
    author_email = 'mayconcipriano@gmail.com',
    packages = ['mkdirPypi'],
    description = 'This project is to create the directory tree to upload your project to Pypi',
    long_description = 'file: README.md',
    url = 'https://github.com/batestin1/',
    project_urls = {
        'Código fonte': 'https://github.com/batestin1/',
        'Download': 'https://github.com/batestin1/'
    },
    keywords = 'This project is to create the directory tree to upload your project to Pypi',
    classifiers = [


    ]
)